﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace DemoXMLDataStorage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            XmlTextWriter xtw;
            xtw = new XmlTextWriter(Environment.CurrentDirectory + "DataBaseXML.xml", Encoding.UTF8);//gán đường dẫn và encoding
            xtw.WriteStartDocument();//Bắt đầu ghi dữ liệu
            xtw.WriteStartElement("CustomerDetails");//Tạo phần tử root
            xtw.WriteEndElement();//Kết thúc phần tử root
            xtw.Close();//Đóng file, nó sẽ tự động save
            MessageBox.Show("Database đã được tạo");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            XmlDocument xd = new XmlDocument();//Khởi tạo đối tượng cho XmlDocument class
            FileStream fs = new FileStream(Environment.CurrentDirectory + "DataBaseXML.xml", FileMode.Open);//Mở file xml ra sử dụng filestream
            xd.Load(fs);//load mở file bằng tài liệu xml
            XmlElement cl = xd.CreateElement("Customer");//Tạo 1 phần tử xml element
            cl.SetAttribute("Name", "abc");//set thuộc tính cho phần tử đó
            XmlElement na = xd.CreateElement("Address");//Tạo 1 phần tử xml element
            XmlText natext = xd.CreateTextNode("xyz,india");//Tạo text cho xml element
            na.AppendChild(natext);//Gán text address vào address node
            cl.AppendChild(na);//gắn node địa chỉ vào phần tử gốc
            xd.DocumentElement.AppendChild(cl);//Gắn phần tử gốc vào xml document
            XmlElement cl1 = xd.CreateElement("Customer");//Tạo 1 phần tử xml element
            cl1.SetAttribute("Name", "Luc Thoi Sang");//set thuộc tính cho phần tử đó
            XmlElement na1 = xd.CreateElement("Address");//Tạo 1 phần tử xml element
            XmlText natext1 = xd.CreateTextNode("TPHCM,VIetNam");//Tạo text cho xml element
            na1.AppendChild(natext1);//Gán text address vào address node
            cl1.AppendChild(na1);//gắn node địa chỉ vào phần tử gốc
            xd.DocumentElement.AppendChild(cl1);//Gắn phần tử gốc vào xml document
            fs.Close();//đóng filestream lại
            xd.Save(Environment.CurrentDirectory + "DataBaseXML.xml");//Lưu nội dung vào file
            MessageBox.Show("Đã ghi dữ liệu thành công");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();
            FileStream rfile = new FileStream(Environment.CurrentDirectory + "DataBaseXML.xml", FileMode.Open);
            xdoc.Load(rfile);
            String address = null;
            XmlNodeList list = xdoc.GetElementsByTagName("Customer");
            for (int i = 0; i < list.Count; i++)
            {
                XmlElement cl = (XmlElement)xdoc.GetElementsByTagName("Customer")[i];
                XmlElement add = (XmlElement)xdoc.GetElementsByTagName("Address")[i];
                if ((cl.GetAttribute("Name")) == textBox1.Text)
                {
                    address = add.InnerText;
                    break;
                }
            }
            rfile.Close();
            MessageBox.Show(address);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            XmlDocument xdoc = new XmlDocument();
            FileStream up = new FileStream(Environment.CurrentDirectory + "DataBaseXML.xml", FileMode.Open);
            xdoc.Load(up);
            XmlNodeList list = xdoc.GetElementsByTagName("Customer");
            for (int i = 0; i < list.Count; i++)
            {
                XmlElement cu = (XmlElement)xdoc.GetElementsByTagName("Customer")[i];
                XmlElement add = (XmlElement)xdoc.GetElementsByTagName("Address")[i];
                if (cu.GetAttribute("Name") == "abc")
                {
                    cu.SetAttribute("Name", "efgh");
                    add.InnerText = "pqrs,india";
                    break;
                }
            }
            up.Close();
            xdoc.Save(Environment.CurrentDirectory + "DataBaseXML.xml");
            MessageBox.Show("Đã update database!!!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FileStream rfile = new FileStream(Environment.CurrentDirectory + "DataBaseXML.xml", FileMode.Open);
            XmlDocument tdoc = new XmlDocument();
            tdoc.Load(rfile);
            XmlNodeList list = tdoc.GetElementsByTagName("Customer");
            for (int i = 0; i < list.Count; i++)
            {
                XmlElement cl = (XmlElement)tdoc.GetElementsByTagName("Customer")[i];
                if (cl.GetAttribute("Name") == "efgh")
                {
                    tdoc.DocumentElement.RemoveChild(cl);
                }
            }
            rfile.Close();
            tdoc.Save(Environment.CurrentDirectory + "DataBaseXML.xml");
            MessageBox.Show("Đã xóa database!!!");
        }
    }
}
